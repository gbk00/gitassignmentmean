const http = require('http');
const calculator = require('./calculator_module');

http.createServer((req, res) => {
  res.writeHead(200, {'Content-Type': 'text/html'});
  res.end(calculator.add(3,4));
}).listen(8080);
const http = require('http');
const fs = require('fs');

http.createServer((req, res) => {
  res.writeHead(200, {'Content-Type': 'text/html'});
  fs.readFile('app.js', function(err, data) {
    fs.writeFile('app_copy.js', data, function(err) {
      if (err) throw err;
      res.end('Success!');
    });
  });
}).listen(8080);